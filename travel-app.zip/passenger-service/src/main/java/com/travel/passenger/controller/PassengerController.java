package com.travel.passenger.controller;

import com.travel.passenger.model.Passenger;
import com.travel.passenger.repository.PassengerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/passengers")
public class PassengerController {
    @Autowired private PassengerRepository repo;

    @GetMapping public List<Passenger> getAll() { return repo.findAll(); }
    @PostMapping public Passenger add(@RequestBody Passenger p) { return repo.save(p); }
    @GetMapping("/{id}") public Passenger get(@PathVariable Long id) { return repo.findById(id).orElse(null); }
    @PutMapping("/{id}") public Passenger update(@PathVariable Long id, @RequestBody Passenger p) {
        Passenger existing = repo.findById(id).orElse(null);
        if (existing != null) {
            existing.setName(p.getName());
            existing.setEmail(p.getEmail());
            return repo.save(existing);
        }
        return null;
    }
    @DeleteMapping("/{id}") public void delete(@PathVariable Long id) { repo.deleteById(id); }
}