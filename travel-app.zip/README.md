# Travel App
Multi-module Spring Boot project for managing passengers, bookings, and fare.
