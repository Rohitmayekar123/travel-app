package com.travel.fare.controller;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/fare")
public class FareController {
    @GetMapping
    public Double calculate(@RequestParam String pickup, @RequestParam String drop) {
        int distance = (int)(Math.random() * 20) + 1;
        return distance * 15.0;
    }
}