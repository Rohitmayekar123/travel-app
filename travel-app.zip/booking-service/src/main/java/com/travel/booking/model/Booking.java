package com.travel.booking.model;

import jakarta.persistence.*;

@Entity
public class Booking {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private Long passengerId;
    private String pickupLocation;
    private String dropLocation;
    private Double fare;
    // Getters and setters
}