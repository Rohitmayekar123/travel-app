package com.travel.booking.service;

import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class FareServiceClient {
    public Double calculateFare(String pickup, String drop) {
        String url = "http://localhost:8082/fare?pickup=" + pickup + "&drop=" + drop;
        return new RestTemplate().getForObject(url, Double.class);
    }
}