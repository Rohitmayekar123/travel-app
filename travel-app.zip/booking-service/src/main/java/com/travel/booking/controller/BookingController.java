package com.travel.booking.controller;

import com.travel.booking.model.Booking;
import com.travel.booking.repository.BookingRepository;
import com.travel.booking.service.FareServiceClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/bookings")
public class BookingController {
    @Autowired private BookingRepository repo;
    @Autowired private FareServiceClient fareClient;

    @GetMapping public List<Booking> getAll() { return repo.findAll(); }

    @PostMapping public Booking book(@RequestBody Booking b) {
        b.setFare(fareClient.calculateFare(b.getPickupLocation(), b.getDropLocation()));
        return repo.save(b);
    }

    @GetMapping("/{id}") public Booking get(@PathVariable Long id) { return repo.findById(id).orElse(null); }
}